from flask import Flask, render_template, request, redirect, url_for, flash, Blueprint, session
from datetime import datetime

#-- importando todas as funções do data_manager.py
from models.data_manager import save_data,load_data

# Cria um Blueprint para as rotas
front_controller = Blueprint('front_controller', __name__)
# Blueprint (front_controller) no controlador (front_controller.py) é um módulo que agrupa rotas relacionadas.
# Flask precisa saber que o front_controller existe, então você o registra, no APP.PY, com app.register_blueprint(front_controller).


#-- rota principal
@front_controller.route('/')
def index():
    return render_template('index.html')

@front_controller.route('/cadastro')
def cadastro():
    return render_template('cadastro.html')

@front_controller.route('/login',  methods=["GET", "POST"])
def login():
    return render_template('login.html')

@front_controller.route('/album',  methods=["GET", "POST"])
def album():
    return render_template('album.html')

@front_controller.route('/sair',  methods=["GET", "POST"])
def sair():
    session.pop('usuario_ativo')
    return render_template('index.html')

@front_controller.route('/autenticar', methods=["GET", "POST"])
def autenticar():

    if (request.method == "POST"):
        usuario_email = request.form.get('email')
        usuario_senha = request.form.get('senha')
        if usuario_email and usuario_senha:
                session['usuario_ativo'] = usuario_email
                flash(usuario_email + ", logado com sucesso!", "success")
                return(redirect(url_for('front_controller.album')))
        else:
                flash("Confira seu usuário e/ou senha. Erro de login.", "danger")
                return(redirect(url_for('front_controller.login')))
        
@front_controller.route('/cadastrar', methods=["GET", "POST"])
def cadastrar():
    if (request.method == "POST"):
        usuario_email = request.form.get('email')
        usuario_senha = request.form.get('senha')
        dados = load_data()
        cadastro = {
            'email': usuario_email,
            'senha': usuario_senha
        }
        existente = False
        for usuario in dados:
             if usuario['email'] == usuario_email:
                  existente = True
                  break
        if existente == False:
            dados.append(cadastro)
            save_data(dados)
            flash("Cadastro feito com sucesso!", "success")
        else:
             flash("Cadastro ja existente!", "danger")
        return render_template('cadastro.html')

