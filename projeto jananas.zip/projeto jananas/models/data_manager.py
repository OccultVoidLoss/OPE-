import os
import json
import config



def save_data(cadastro):
    with open(config.DATA_FILE, "w") as file:
        json.dump(cadastro, file, indent=4)

def load_data():
    if not os.path.exists(config.DATA_FILE):
        return [ ]
    with open(config.DATA_FILE, "r") as file:
        return (json.load(file))
        


#-- FUNÇÕES PARA MANIPULAR OS REGISTRO DO ARQUIVO

#retorna todos os itens armazenados.
def get_all_items():
    return load_data()

#retorna um item específico pelo ID ou vazio, caso não encontre.
def get_item_by_id(item_id):
    items = load_data()
    return next((item for item in items if item['id'] == item_id), None)

#adiciona um novo item com base nos dados do formulário (parâmetro).
def add_new_item(form_data):
    name = form_data.get('name')
    status = form_data.get('status', 'a_fazer')  # Valor default, caso esteja em branco: 'a_fazer'
    
    if not name:
        return (False, 'É necessário preencher o nome da tarefa!')
    
    items = load_data()
    
    #cria um ID automático - próximo valor inteiro a partir da última tarefa cadastrada
    new_id = max([item['id'] for item in items], default=0) + 1
    
    new_item = {"id": new_id, "name": name, "status": status}
    items.append(new_item)
    save_data(items)
    return (True, None)

#altera (atualiza) um item existente.
def update_item(item_id, form_data):
    items = load_data()
    item = next((i for i in items if i['id'] == item_id), None)
    if (item):
        item['name'] = form_data.get('name')
        item['status'] = form_data.get('status', item['status'])  # Atualiza o status
        save_data(items)
        return True
    return False

#remove um item pelo ID.
def delete_item(item_id):
    items = load_data()
    updated_items = [item for item in items if item['id'] != item_id]
    save_data(updated_items)
    return True